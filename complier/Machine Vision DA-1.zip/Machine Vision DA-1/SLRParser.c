#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

char terminals[100];
int no_t;
char non_terminals[100];
int no_nt;
char goto_table[100][100];
char reduce[20][20];
char follow[20][20];
char fo_co[20][20];
char first[20][20];

// Action table entries can be: 'S' (shift), 'R' (reduce), 'A' (accept), or ' ' (error)
char action_type[100][100];
int action_value[100][100]; // Contains state number for shift or production number for reduce

struct state {
    int prod_count;
    char prod[100][100];
};

void add_dots(struct state *I) {
    for (int i = 0; i < I->prod_count; i++) {
        for (int j = 99; j > 3; j--)
            I->prod[i][j] = I->prod[i][j - 1];
        I->prod[i][3] = '.';
    }
}

void augument(struct state *S, struct state *I) {
    if (I->prod[0][0] == 'S')
        strcpy(S->prod[0], "Z->.S");
    else {
        strcpy(S->prod[0], "S->.");
        S->prod[0][4] = I->prod[0][0];
    }
    S->prod_count++;
}

void get_prods(struct state *I) {
    printf("Enter the number of productions:\n");
    scanf("%d", &I->prod_count);
    printf("Enter the number of non terminals:\n");
    scanf("%d", &no_nt);
    printf("Enter the non terminals one by one:\n");
    for (int i = 0; i < no_nt; i++)
        scanf(" %c", &non_terminals[i]);
    printf("Enter the number of terminals:\n");
    scanf("%d", &no_t);
    printf("Enter the terminals (single lettered) one by one:\n");
    for (int i = 0; i < no_t; i++)
        scanf(" %c", &terminals[i]);
    printf("Enter the productions one by one in form (S->ABc):\n");
    for (int i = 0; i < I->prod_count; i++) {
        scanf("%s", I->prod[i]);
    }
}

bool is_non_terminal(char a) {
    if (a >= 'A' && a <= 'Z')
        return true;
    else
        return false;
}

bool in_state(struct state *I, char *a) {
    for (int i = 0; i < I->prod_count; i++) {
        if (!strcmp(I->prod[i], a))
            return true;
    }
    return false;
}

char char_after_dot(char a[100]) {
    char b;
    for (int i = 0; i < strlen(a); i++)
        if (a[i] == '.') {
            b = a[i + 1];
            return b;
        }
    return '\0';
}

void move_dot(char b[100], char result[100]) {
    strcpy(result, b);
    for (int i = 0; i < strlen(result); i++) {
        if (result[i] == '.') {
            char temp = result[i];
            result[i] = result[i + 1];
            result[i + 1] = temp;
            break;
        }
    }
}

bool same_state(struct state *I0, struct state *I) {
    if (I0->prod_count != I->prod_count)
        return false;

    for (int i = 0; i < I0->prod_count; i++) {
        int flag = 0;
        for (int j = 0; j < I->prod_count; j++)
            if (strcmp(I0->prod[i], I->prod[j]) == 0)
                flag = 1;
        if (flag == 0)
            return false;
    }
    return true;
}

void closure(struct state *I, struct state *I0) {
    char a;
    for (int i = 0; i < I0->prod_count; i++) {
        a = char_after_dot(I0->prod[i]);
        if (is_non_terminal(a)) {
            for (int j = 0; j < I->prod_count; j++) {
                if (I->prod[j][0] == a) {
                    if (!in_state(I0, I->prod[j])) {
                        strcpy(I0->prod[I0->prod_count], I->prod[j]);
                        I0->prod_count++;
                    }
                }
            }
        }
    }
}

void goto_state(struct state *I, struct state *S, char a) {
    int time = 1;
    char moved[100];

    for (int i = 0; i < I->prod_count; i++) {
        if (char_after_dot(I->prod[i]) == a) {
            if (time == 1) {
                time++;
            }
            move_dot(I->prod[i], moved);
            strcpy(S->prod[S->prod_count], moved);
            S->prod_count++;
        }
    }
}

void print_prods(struct state *I) {
    for (int i = 0; i < I->prod_count; i++)
        printf("%s\n", I->prod[i]);
    printf("\n");
}

bool in_array(char a[20], char b) {
    for (int i = 0; i < strlen(a); i++)
        if (a[i] == b)
            return true;
    return false;
}

void chars_after_dots(struct state *I, char result[20]) {
    memset(result, 0, 20);
    for (int i = 0; i < I->prod_count; i++) {
        char c = char_after_dot(I->prod[i]);
        if (!in_array(result, c)) {
            result[strlen(result)] = c;
        }
    }
}

void cleanup_prods(struct state * I) {
    for (int i = 0; i < I->prod_count; i++)
        I->prod[i][0] = '\0';
    I->prod_count = 0;
}

int return_index(char a) {
    for (int i = 0; i < no_t; i++)
        if (terminals[i] == a)
            return i;
    for (int i = 0; i < no_nt; i++)
        if (non_terminals[i] == a)
            return no_t + i;
    return -1;
}

void add_dot_at_end(struct state* I) {
    for (int i = 0; i < I->prod_count; i++) {
        strcat(I->prod[i], ".");
    }
}

void add_to_first(int n, char b) {
    for (int i = 0; i < strlen(first[n]); i++)
        if (first[n][i] == b)
            return;
    first[n][strlen(first[n])] = b;
}

void add_to_first_from_another(int m, int n) {
    for (int i = 0; i < strlen(first[n]); i++) {
        int flag = 0;
        for (int j = 0; j < strlen(first[m]); j++) {
            if (first[n][i] == first[m][j])
                flag = 1;
        }
        if (flag == 0)
            add_to_first(m, first[n][i]);
    }
}

void add_to_follow(int n, char b) {
    for (int i = 0; i < strlen(follow[n]); i++)
        if (follow[n][i] == b)
            return;
    follow[n][strlen(follow[n])] = b;
}

void add_to_follow_from_another(int m, int n) {
    for (int i = 0; i < strlen(follow[n]); i++) {
        int flag = 0;
        for (int j = 0; j < strlen(follow[m]); j++) {
            if (follow[n][i] == follow[m][j])
                flag = 1;
        }
        if (flag == 0)
            add_to_follow(m, follow[n][i]);
    }
}

void add_to_follow_first(int m, int n) {
    for (int i = 0; i < strlen(first[n]); i++) {
        int flag = 0;
        for (int j = 0; j < strlen(follow[m]); j++) {
            if (first[n][i] == follow[m][j])
                flag = 1;
        }
        if (flag == 0)
            add_to_follow(m, first[n][i]);
    }
}

void find_first(struct state *I) {
    for (int i = 0; i < no_nt; i++) {
        for (int j = 0; j < I->prod_count; j++) {
            if (I->prod[j][0] == non_terminals[i]) {
                if (!is_non_terminal(I->prod[j][3])) {
                    add_to_first(i, I->prod[j][3]);
                }
            }
        }
    }
}

void find_follow(struct state *I) {
    for (int i = 0; i < no_nt; i++) {
        for (int j = 0; j < I->prod_count; j++) {
            for (int k = 3; k < strlen(I->prod[j]); k++) {
                if (I->prod[j][k] == non_terminals[i]) {
                    if (I->prod[j][k + 1] != '\0') {
                        if (!is_non_terminal(I->prod[j][k + 1])) {
                            add_to_follow(i, I->prod[j][k + 1]);
                        }
                    }
                }
            }
        }
    }
}

// Initialize the action and goto tables
void init_tables(int state_count) {
    // Initialize all entries to error
    for (int i = 0; i < state_count; i++) {
        for (int j = 0; j < no_t; j++) {
            action_type[i][j] = ' ';
            action_value[i][j] = -1;
        }

        for (int j = 0; j < no_nt; j++) {
            action_type[i][no_t + j] = ' ';
            action_value[i][no_t + j] = -1;
        }
    }
}

// Populate the shift actions and goto entries
void populate_shift_goto(int state_count) {
    for (int i = 0; i < state_count; i++) {
        for (int j = 0; j < state_count; j++) {
            if (goto_table[i][j] != '~') {
                int index = return_index(goto_table[i][j]);
                if (index < no_t) {
                    // This is a terminal, so it's a shift action
                    action_type[i][index] = 'S';
                    action_value[i][index] = j;
                } else {
                    // This is a non-terminal, so it's a goto entry
                    action_type[i][index] = ' '; // Goto entries don't have a type
                    action_value[i][index] = j;
                }
            }
        }
    }

    // Set the accept state
    action_type[1][no_t - 1] = 'A'; // Accept on $ for state 1
    action_value[1][no_t - 1] = 0;
}

// Populate the reduce actions
void populate_reduce(int state_count, int *no_re, struct state *temp1) {
    for (int i = 0; i < temp1->prod_count; i++) {
        int n = no_re[i];
        if (n != -1) { // If this production has a reduce state
            int idx = return_index(temp1->prod[i][0]) - no_t;

            if (idx >= 0 && idx < no_nt) {
                for (int j = 0; j < strlen(follow[idx]); j++) {
                    int term_idx = return_index(follow[idx][j]);
                    if (term_idx >= 0 && term_idx < no_t) {
                        // Only set reduce if there's no shift action already
                        if (action_type[n][term_idx] == ' ') {
                            action_type[n][term_idx] = 'R';
                            action_value[n][term_idx] = i + 1; // Production number
                        }
                    }
                }
            }
        }
    }
}

// Print the merged parsing table
void print_parsing_table(int state_count, struct state *temp1) {
    printf("\n********** MERGED PARSING TABLE **********\n\n");

    // Print header
    printf("STATE\t");
    // Print terminal symbols (Action columns)
    for (int i = 0; i < no_t; i++) {
        printf("%c\t", terminals[i]);
    }
    // Print non-terminal symbols (Goto columns)
    for (int i = 0; i < no_nt; i++) {
        printf("%c\t", non_terminals[i]);
    }
    printf("\n");

    // Print table rows
    for (int i = 0; i < state_count; i++) {
        printf("%d\t", i);

        // Print action part
        for (int j = 0; j < no_t; j++) {
            if (action_type[i][j] == 'S') {
                printf("S%d\t", action_value[i][j]);
            } else if (action_type[i][j] == 'R') {
                printf("R%d\t", action_value[i][j]);
            } else if (action_type[i][j] == 'A') {
                printf("ACC\t");
            } else {
                printf("\t"); // Error state
            }
        }

        // Print goto part
        for (int j = 0; j < no_nt; j++) {
            int idx = no_t + j;
            if (action_value[i][idx] != -1) {
                printf("%d\t", action_value[i][idx]);
            } else {
                printf("\t");
            }
        }
        printf("\n");
    }

    // Print production information for reference
    printf("\n********** PRODUCTIONS **********\n");
    for (int i = 0; i < temp1->prod_count; i++) {
        // Remove dot from production for display
        char prod_display[100];
        int dot_pos = -1;
        strcpy(prod_display, temp1->prod[i]);

        for (int j = 0; j < strlen(prod_display); j++) {
            if (prod_display[j] == '.') {
                dot_pos = j;
                break;
            }
        }

        if (dot_pos != -1) {
            for (int j = dot_pos; j < strlen(prod_display) - 1; j++) {
                prod_display[j] = prod_display[j + 1];
            }
            prod_display[strlen(prod_display) - 1] = '\0';
        }

        printf("R%d: %s\n", i + 1, prod_display);
    }
}

int main() {
    struct state init;
    struct state temp;
    struct state temp1;
    int state_count = 1;

    // Initialize structures
    init.prod_count = 0;
    temp.prod_count = 0;
    temp1.prod_count = 0;

    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 100; j++) {
            goto_table[i][j] = '~';
        }
    }

    get_prods(&init);
    temp = init;
    temp1 = temp;
    add_dots(&init);

    struct state I[50];
    for (int i = 0; i < 50; i++) {
        I[i].prod_count = 0;
    }

    augument(&I[0], &init);
    closure(&init, &I[0]);
    printf("\nI0:\n");
    print_prods(&I[0]);

    for (int i = 0; i < state_count; i++) {
        char characters[20] = {0};
        chars_after_dots(&I[i], characters);

        for (int j = 0; j < strlen(characters); j++) {
            goto_state(&I[i], &I[state_count], characters[j]);
            closure(&init, &I[state_count]);
            int flag = 0;
            for (int k = 0; k < state_count; k++) {
                if (same_state(&I[k], &I[state_count])) {
                    cleanup_prods(&I[state_count]);
                    flag = 1;
                    printf("I%d on reading the symbol %c goes to I%d.\n", i, characters[j], k);
                    goto_table[i][k] = characters[j];
                    break;
                }
            }
            if (flag == 0) {
                state_count++;
                printf("I%d on reading the symbol %c goes to I%d:\n", i, characters[j], state_count - 1);
                goto_table[i][state_count - 1] = characters[j];
                print_prods(&I[state_count - 1]);
            }
        }
    }

    int no_re[100]; // Assuming temp.prod_count < 100
    for (int i = 0; i < temp.prod_count; i++) {
        no_re[i] = -1;
    }

    terminals[no_t] = '$';
    no_t++;

    add_dot_at_end(&temp1);
    for (int i = 0; i < state_count; i++) {
        for (int j = 0; j < I[i].prod_count; j++) {
            for (int k = 0; k < temp1.prod_count; k++) {
                if (in_state(&I[i], temp1.prod[k]))
                    no_re[k] = i;
            }
        }
    }

    find_first(&temp);
    for (int l = 0; l < no_nt; l++) {
        for (int i = 0; i < temp.prod_count; i++) {
            if (is_non_terminal(temp.prod[i][3])) {
                int idx1 = return_index(temp.prod[i][0]) - no_t;
                int idx2 = return_index(temp.prod[i][3]) - no_t;
                if (idx1 >= 0 && idx1 < no_nt && idx2 >= 0 && idx2 < no_nt) {
                    add_to_first_from_another(idx1, idx2);
                }
            }
        }
    }

    find_follow(&temp);
    add_to_follow(0, '$');
    for (int l = 0; l < no_nt; l++) {
        for (int i = 0; i < temp.prod_count; i++) {
            for (int k = 3; k < strlen(temp.prod[i]); k++) {
                if (temp.prod[i][k] == non_terminals[l]) {
                    if (temp.prod[i][k + 1] != '\0') {
                        if (is_non_terminal(temp.prod[i][k + 1])) {
                            int idx = return_index(temp.prod[i][k + 1]) - no_t;
                            if (idx >= 0 && idx < no_nt) {
                                add_to_follow_first(l, idx);
                            }
                        }
                    }
                    if (temp.prod[i][k + 1] == '\0') {
                        int idx = return_index(temp.prod[i][0]) - no_t;
                        if (idx >= 0 && idx < no_nt) {
                            add_to_follow_from_another(l, idx);
                        }
                    }
                }
            }
        }
    }

    // Initialize tables
    init_tables(state_count);
    // Populate shift and goto actions
    populate_shift_goto(state_count);
    // Populate reduce actions
    populate_reduce(state_count, no_re, &temp1);
    // Print the merged parsing table
    print_parsing_table(state_count, &temp1);

    return 0;
}

