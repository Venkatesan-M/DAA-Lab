#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

// --------------------- Data Structures ---------------------
struct Symbol {
    char *name;
    struct Symbol *next;
};

struct Production {
    struct Symbol *symbols;
    struct Production *next;
};

struct Node {
    char *symbol;
    struct Node *next;
};

struct NonTerminal {
    char *name;
    struct Production *productions;
    struct Node *leading;
    struct Node *trailing;
    struct NonTerminal *next;
};

// Modified Terminal structure to include function values f(x) and g(x)
struct Terminal {
    char *name;
    int f_value; // Left precedence function value
    int g_value; // Right precedence function value
    struct Terminal *next;
};

// Relation types for operator precedence
#define REL_LESS 1    // <·
#define REL_EQUAL 2   // =
#define REL_GREATER 3 // ·>
#define REL_ERROR 0   // Error/undefined

// --------------------- Global Variables ---------------------
struct NonTerminal *non_terminals = NULL;
struct Terminal *terminals = NULL;
int **precedence_table = NULL;
int terminal_count = 0;
char *start_symbol = NULL;

// --------------------- Utility Functions ---------------------
// Trim leading and trailing whitespace
char *trim(char *str) {
    char *end;
    while (isspace((unsigned char)*str))
        str++;
    if (*str == 0)
        return str;
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end))
        end--;
    *(end + 1) = '\0';
    return str;
}

struct NonTerminal *find_non_terminal(const char *name) {
    struct NonTerminal *nt = non_terminals;
    while (nt != NULL) {
        if (strcmp(nt->name, name) == 0)
            return nt;
        nt = nt->next;
    }
    return NULL;
}

void add_production(struct NonTerminal *nt, struct Symbol *symbols) {
    struct Production *prod = malloc(sizeof(struct Production));
    prod->symbols = symbols;
    prod->next = nt->productions;
    nt->productions = prod;
}

bool is_non_terminal(const char *symbol) {
    return find_non_terminal(symbol) != NULL;
}

bool is_in_set(struct Node *set, const char *symbol) {
    struct Node *node = set;
    while (node != NULL) {
        if (strcmp(node->symbol, symbol) == 0)
            return true;
        node = node->next;
    }
    return false;
}

void add_to_set(struct Node **set, const char *symbol) {
    if (is_in_set(*set, symbol))
        return;
    struct Node *node = malloc(sizeof(struct Node));
    node->symbol = strdup(symbol);
    node->next = *set;
    *set = node;
}

// --------------------- Computation of Leading/Trailing Sets ---------------------
void compute_leading() {
    bool changed;
    do {
        changed = false;
        struct NonTerminal *nt = non_terminals;
        while (nt != NULL) {
            struct Production *prod = nt->productions;
            while (prod != NULL) {
                struct Symbol *symbol = prod->symbols;
                char *first_terminal = NULL;
                while (symbol != NULL) {
                    if (!is_non_terminal(symbol->name))
                        first_terminal = symbol->name;
                    if (first_terminal != NULL)
                        break;
                    symbol = symbol->next;
                }
                if (first_terminal != NULL && !is_in_set(nt->leading, first_terminal)) {
                    add_to_set(&nt->leading, first_terminal);
                    changed = true;
                }
                if (prod->symbols != NULL) {
                    char *first_sym = prod->symbols->name;
                    if (is_non_terminal(first_sym)) {
                        struct NonTerminal *B = find_non_terminal(first_sym);
                        if (B != NULL) {
                            struct Node *b_leading = B->leading;
                            while (b_leading != NULL) {
                                if (!is_non_terminal(b_leading->symbol) &&
                                    !is_in_set(nt->leading, b_leading->symbol)) {
                                    add_to_set(&nt->leading, b_leading->symbol);
                                    changed = true;
                                }
                                b_leading = b_leading->next;
                            }
                        }
                    }
                }
                prod = prod->next;
            }
            nt = nt->next;
        }
    } while (changed);
}

void compute_trailing() {
    bool changed;
    do {
        changed = false;
        struct NonTerminal *nt = non_terminals;
        while (nt != NULL) {
            struct Production *prod = nt->productions;
            while (prod != NULL) {
                struct Symbol *symbol = prod->symbols;
                char *last_terminal = NULL;
                while (symbol != NULL) {
                    if (!is_non_terminal(symbol->name))
                        last_terminal = symbol->name;
                    symbol = symbol->next;
                }
                if (last_terminal != NULL && !is_in_set(nt->trailing, last_terminal)) {
                    add_to_set(&nt->trailing, last_terminal);
                    changed = true;
                }
                struct Symbol *last_sym_node = prod->symbols;
                while (last_sym_node != NULL && last_sym_node->next != NULL)
                    last_sym_node = last_sym_node->next;
                if (last_sym_node != NULL) {
                    char *last_sym = last_sym_node->name;
                    if (is_non_terminal(last_sym)) {
                        struct NonTerminal *B = find_non_terminal(last_sym);
                        if (B != NULL) {
                            struct Node *b_trailing = B->trailing;
                            while (b_trailing != NULL) {
                                if (!is_non_terminal(b_trailing->symbol) &&
                                    !is_in_set(nt->trailing, b_trailing->symbol)) {
                                    add_to_set(&nt->trailing, b_trailing->symbol);
                                    changed = true;
                                }
                                b_trailing = b_trailing->next;
                            }
                        }
                    }
                }
                prod = prod->next;
            }
            nt = nt->next;
        }
    } while (changed);
}

// --------------------- Terminal Collection and Precedence Table ---------------------
// Find or add a terminal to the terminal list
int get_terminal_index(const char *name) {
    struct Terminal *t = terminals;
    int index = 0;
    while (t != NULL) {
        if (strcmp(t->name, name) == 0)
            return index;
        t = t->next;
        index++;
    }
    // Add new terminal
    t = malloc(sizeof(struct Terminal));
    t->name = strdup(name);
    t->f_value = 0; // to be set later
    t->g_value = 0;
    t->next = terminals;
    terminals = t;
    return terminal_count++;
}

// Collect all terminals used in the grammar (including "$")
void collect_terminals() {
    // Add "$" as the first terminal (index 0)
    get_terminal_index("$");
    struct NonTerminal *nt = non_terminals;
    while (nt != NULL) {
        struct Production *prod = nt->productions;
        while (prod != NULL) {
            struct Symbol *sym = prod->symbols;
            while (sym != NULL) {
                if (!is_non_terminal(sym->name))
                    get_terminal_index(sym->name);
                sym = sym->next;
            }
            prod = prod->next;
        }
        nt = nt->next;
    }
}

// Initialize the precedence table with REL_ERROR
void init_precedence_table() {
    precedence_table = malloc(terminal_count * sizeof(int *));
    for (int i = 0; i < terminal_count; i++) {
        precedence_table[i] = malloc(terminal_count * sizeof(int));
        for (int j = 0; j < terminal_count; j++) {
            precedence_table[i][j] = REL_ERROR;
        }
    }
}

// Set the relation between two terminals in the precedence table
void set_relation(const char *a, const char *b, int relation) {
    int a_index = get_terminal_index(a);
    int b_index = get_terminal_index(b);
    precedence_table[a_index][b_index] = relation;
}

// Get the terminal name by index (for printing)
char *get_terminal_name(int index) {
    struct Terminal *t = terminals;
    int i = 0;
    while (t != NULL && i < index) {
        t = t->next;
        i++;
    }
    return (t != NULL) ? t->name : "Unknown";
}

// --------------------- Building the Operator Precedence Table ---------------------
void build_precedence_table() {
    // Rule 1a: set $ <· a for all a in LEADING(S)
    if (start_symbol != NULL) {
        struct NonTerminal *start = find_non_terminal(start_symbol);
        if (start != NULL) {
            struct Node *a = start->leading;
            while (a != NULL) {
                set_relation("$", a->symbol, REL_LESS);
                a = a->next;
            }
            // Rule 1b: set b ·> $ for all b in TRAILING(S)
            struct Node *b = start->trailing;
            while (b != NULL) {
                set_relation(b->symbol, "$", REL_GREATER);
                b = b->next;
            }
        }
    }
    // Process productions for Rules 2, 3, and 4
    struct NonTerminal *nt = non_terminals;
    while (nt != NULL) {
        struct Production *prod = nt->productions;
        while (prod != NULL) {
            struct Symbol *current = prod->symbols;
            while (current != NULL && current->next != NULL) {
                char *x = current->name;
                char *y = current->next->name;
                // Rule 2a: if A -> x y, with x and y terminals, set x = y
                if (!is_non_terminal(x) && !is_non_terminal(y))
                    set_relation(x, y, REL_EQUAL);
                // Rule 2b: if A -> x B y, with x and y terminals and B nonterminal
                if (!is_non_terminal(x) &&
                    current->next->next != NULL &&
                    is_non_terminal(y) &&
                    !is_non_terminal(current->next->next->name))
                    set_relation(x, current->next->next->name, REL_EQUAL);
                // Rule 3: if A -> x B, with x terminal, set x < a for all a in LEADING(B)
                if (!is_non_terminal(x) && is_non_terminal(y)) {
                    struct NonTerminal *B = find_non_terminal(y);
                    if (B != NULL) {
                        struct Node *a = B->leading;
                        while (a != NULL) {
                            set_relation(x, a->symbol, REL_LESS);
                            a = a->next;
                        }
                    }
                }
                // Rule 4: if A -> B y, with y terminal, set b > y for all b in TRAILING(B)
                if (is_non_terminal(x) && !is_non_terminal(y)) {
                    struct NonTerminal *B = find_non_terminal(x);
                    if (B != NULL) {
                        struct Node *b = B->trailing;
                        while (b != NULL) {
                            set_relation(b->symbol, y, REL_GREATER);
                            b = b->next;
                        }
                    }
                }
                current = current->next;
            }
            prod = prod->next;
        }
        nt = nt->next;
    }
    // Undefined entries remain as REL_ERROR.
}

// --------------------- Building the Operator Precedence Functional Table ---------------------
// Here, we swap the assignments for f(x) and g(x).
// That is, for non-endmarker terminals, we assign:
// f(x) = value + 1 and g(x) = value
// For the end-marker "$", we keep f("$") = 0 and g("$") = 0.
void build_function_table() {
    int value = 1;
    struct Terminal *t = terminals;
    while (t != NULL) {
        if (strcmp(t->name, "$") == 0) {
            t->f_value = 0;
            t->g_value = 0;
        } else {
            t->f_value = value + 1; // Swapped: now f(x) gets the higher value
            t->g_value = value;     // and g(x) gets the lower value
            value += 2;             // leave a gap for adjustments if needed
        }
        t = t->next;
    }
}

// Print the Operator Precedence Functional Table
void print_function_table() {
    printf("\nOperator Precedence Functional Table:\n");
    printf("%-4s %-10s %-8s %-8s\n", "ID", "Terminal", "f(x)", "g(x)");
    printf("--------------------------------------\n");
    int index = 0;
    struct Terminal *t = terminals;
    while (t != NULL) {
        printf("%-4d %-10s %-8d %-8d\n", index, t->name, t->f_value, t->g_value);
        t = t->next;
        index++;
    }
}

// --------------------- Print Leading/Trailing Sets ---------------------
void print_set(struct Node *set) {
    struct Node *node = set;
    while (node != NULL) {
        printf("%s", node->symbol);
        node = node->next;
        if (node != NULL)
            printf(", ");
    }
}

// --------------------- Freeing Allocated Memory ---------------------
void free_symbols(struct Symbol *symbol) {
    while (symbol != NULL) {
        struct Symbol *next = symbol->next;
        free(symbol->name);
        free(symbol);
        symbol = next;
    }
}

void free_productions(struct Production *prod) {
    while (prod != NULL) {
        struct Production *next = prod->next;
        free_symbols(prod->symbols);
        free(prod);
        prod = next;
    }
}

void free_terminals() {
    struct Terminal *t = terminals;
    while (t != NULL) {
        struct Terminal *next = t->next;
        free(t->name);
        free(t);
        t = next;
    }
}

void free_precedence_table() {
    if (precedence_table != NULL) {
        for (int i = 0; i < terminal_count; i++) {
            free(precedence_table[i]);
        }
        free(precedence_table);
    }
}

void free_non_terminals() {
    struct NonTerminal *nt = non_terminals;
    while (nt != NULL) {
        struct NonTerminal *next = nt->next;
        free_productions(nt->productions);
        struct Node *node = nt->leading;
        while (node != NULL) {
            struct Node *next_node = node->next;
            free(node->symbol);
            free(node);
            node = next_node;
        }
        node = nt->trailing;
        while (node != NULL) {
            struct Node *next_node = node->next;
            free(node->symbol);
            free(node);
            node = next_node;
        }
        free(nt->name);
        free(nt);
        nt = next;
    }
}

// --------------------- Main Function ---------------------
int main() {
    char line[256];
    int num_productions;
    printf("Enter the number of productions(E -> E + T) : ");
    if (fgets(line, sizeof(line), stdin) == NULL) {
        fprintf(stderr, "Error reading number of productions.\n");
        exit(1);
    }
    num_productions = atoi(line);
    for (int i = 0; i < num_productions; ++i) {
        printf("Production No. %d: ", i + 1);
        if (fgets(line, sizeof(line), stdin) == NULL) {
            fprintf(stderr, "Error reading production input.\n");
            exit(1);
        }
        size_t len = strlen(line);
        if (len > 0 && line[len - 1] == '\n')
            line[len - 1] = '\0';
        char *arrow = strstr(line, "->");
        if (arrow == NULL) {
            fprintf(stderr, "Invalid production format. Use 'NonTerminal -> symbols...'\n");
            --i;
            continue;
        }
        *arrow = '\0';
        char *lhs = trim(line);
        char *rhs = trim(arrow + 2);
        // Set the first non-terminal as the start symbol
        if (i == 0) {
            start_symbol = strdup(lhs);
        }
        lhs = strdup(lhs);
        struct Symbol *symbols = NULL;
        struct Symbol **next_ptr = &symbols;
        char *token = strtok(rhs, " ");
        while (token != NULL) {
            struct Symbol *sym = malloc(sizeof(struct Symbol));
            sym->name = strdup(token);
            sym->next = NULL;
            *next_ptr = sym;
            next_ptr = &sym->next;
            token = strtok(NULL, " ");
        }
        struct NonTerminal *nt = find_non_terminal(lhs);
        if (nt == NULL) {
            nt = malloc(sizeof(struct NonTerminal));
            nt->name = lhs;
            nt->productions = NULL;
            nt->leading = NULL;
            nt->trailing = NULL;
            nt->next = non_terminals;
            non_terminals = nt;
        } else {
            free(lhs);
        }
        add_production(nt, symbols);
    }
    // Compute leading and trailing sets
    compute_leading();
    compute_trailing();
    printf("\nLeading and Trailing sets:\n");
    struct NonTerminal *nt = non_terminals;
    while (nt != NULL) {
        printf("LEADING(%s) = { ", nt->name);
        print_set(nt->leading);
        printf(" }\n");
        printf("TRAILING(%s) = { ", nt->name);
        print_set(nt->trailing);
        printf(" }\n");
        nt = nt->next;
    }
    // Build the operator precedence table from the grammar rules
    collect_terminals();
    init_precedence_table();
    build_precedence_table();
    
    // Build and print the Operator Precedence Functional Table (with swapped f(x) and g(x))
    build_function_table();
    print_function_table();
    // Clean up
    free_terminals();
    free_precedence_table();
    if (start_symbol)
        free(start_symbol);
    free_non_terminals();
    return 0;
}

