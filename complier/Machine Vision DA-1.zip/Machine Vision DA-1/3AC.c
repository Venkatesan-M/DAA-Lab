#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX 100
#define ID_SIZE 10 // Size of identifier strings

// Stack for Operators
char stack[MAX];
int top = -1;

void push(char c) {
    if (top == MAX - 1) {
        printf("Stack overflow\n");
        return;
    }
    stack[++top] = c;
}

char pop() {
    if (top == -1) {
        return '\0';
    }
    return stack[top--];
}

char peek() {
    if (top == -1) {
        return '\0';
    }
    return stack[top];
}

// Operator precedence
int precedence(char c) {
    switch (c) {
        case '+': 
        case '-': 
            return 1;
        case '*': 
        case '/': 
            return 2;
        case '^': 
            return 3;
        default: 
            return 0;
    }
}

// Structs for Quadruples and Triples
typedef struct {
    char op;
    char arg1[ID_SIZE], arg2[ID_SIZE], result[ID_SIZE];
} Quadruple;

typedef struct {
    char op;
    char arg1[ID_SIZE], arg2[ID_SIZE];
} Triple;

Quadruple quads[MAX];
Triple triples[MAX];
int indirectTriples[MAX];
int quadIndex = 0, tripleIndex = 0;

// Convert infix to postfix
void generatePostfix(char *expr, char *postfix) {
    int i, k = 0;
    for (i = 0; expr[i] != '\0'; i++) {
        if (isalnum(expr[i])) {
            postfix[k++] = expr[i];
        } else if (expr[i] == '(') {
            push(expr[i]);
        } else if (expr[i] == ')') {
            while (top != -1 && peek() != '(') {
                postfix[k++] = pop();
            }
            pop();
        } else {
            while (top != -1 && precedence(peek()) >= precedence(expr[i])) {
                postfix[k++] = pop();
            }
            push(expr[i]);
        }
    }
    while (top != -1) {
        postfix[k++] = pop();
    }
    postfix[k] = '\0';
}

// Function to safely convert index to string with bounds checking
void indexToString(int index, char *buffer, size_t bufferSize) {
    // For triple indices, limit to 2 digits max (0-99)
    // This ensures max string length of 2 characters + null terminator
    if (index < 100) {
        snprintf(buffer, bufferSize, "%d", index);
    } else {
        // Use modulo to cycle back for larger values
        snprintf(buffer, bufferSize, "%d", index % 100);
    }
}

// Safe function to create temporary variable names
void createTempVar(int count, char *buffer, size_t bufferSize) {
    // Ensure we only use single or double-digit numbers (T0-T99)
    // "T" + 2 digits + null = 4 bytes max
    if (count < 100) {
        snprintf(buffer, bufferSize, "T%d", count);
    } else {
        // Use modulo to cycle back for larger values
        snprintf(buffer, bufferSize, "T%d", count % 100);
    }
}

// Generate 3AC and populate Quadruples, Triples, and Indirect Triples
void generate3AC(char *postfix) {
    char tempStack[MAX][ID_SIZE];
    int tempTop = -1, count = 1;
    
    printf("\nThree Address Code:\n");
    
    for (int i = 0; postfix[i] != '\0'; i++) {
        if (isalnum(postfix[i])) {
            char temp[2] = {postfix[i], '\0'};
            strcpy(tempStack[++tempTop], temp);
        } else {
            char op2[ID_SIZE], op1[ID_SIZE], res[ID_SIZE];
            strcpy(op2, tempStack[tempTop--]);
            strcpy(op1, tempStack[tempTop--]);
            
            // Safe generation of temporary variable names
            createTempVar(count++, res, sizeof(res));
            
            // Print 3AC
            printf("%s = %s %c %s\n", res, op1, postfix[i], op2);
            
            // Store in Quadruples
            quads[quadIndex].op = postfix[i];
            strcpy(quads[quadIndex].arg1, op1);
            strcpy(quads[quadIndex].arg2, op2);
            strcpy(quads[quadIndex].result, res);
            quadIndex++;
            
            // Store in Triples (use index instead of T1, T2, etc.)
            triples[tripleIndex].op = postfix[i];
            if (op1[0] == 'T') { // If op1 is a temporary variable
                indexToString(tripleIndex - 1, triples[tripleIndex].arg1,
                              sizeof(triples[tripleIndex].arg1));
            } else {
                strcpy(triples[tripleIndex].arg1, op1);
            }
            
            if (op2[0] == 'T') { // If op2 is a temporary variable
                indexToString(tripleIndex - 1, triples[tripleIndex].arg2,
                              sizeof(triples[tripleIndex].arg2));
            } else {
                strcpy(triples[tripleIndex].arg2, op2);
            }
            
            tripleIndex++;
            
            // Store Indirect Triples as references to Triples
            indirectTriples[tripleIndex - 1] = tripleIndex - 1;
            
            // Push result onto stack for further computations
            strcpy(tempStack[++tempTop], res);
        }
    }
}

// Print Quadruples Representation
void printQuadruples() {
    printf("\nQuadruples:\n");
    printf("+------+-----+-----+------+\n");
    printf("| OP | A1 | A2 | RES |\n");
    printf("+------+-----+-----+------+\n");
    for (int i = 0; i < quadIndex; i++) {
        printf("| %c | %s | %s | %s |\n", quads[i].op, quads[i].arg1, quads[i].arg2,
               quads[i].result);
    }
    printf("+------+-----+-----+------+\n");
}

// Print Triples Representation
void printTriples() {
    printf("\nTriples:\n");
    printf("+------+-----+-----+\n");
    printf("| OP | A1 | A2 |\n");
    printf("+------+-----+-----+\n");
    for (int i = 0; i < tripleIndex; i++) {
        printf("| %c | %s | %s |\n", triples[i].op, triples[i].arg1, triples[i].arg2);
    }
    printf("+------+-----+-----+\n");
}

// Print Indirect Triples Representation
void printIndirectTriples() {
    printf("\nIndirect Triples:\n");
    printf("+------+---------+\n");
    printf("| INDEX| ENTRY |\n");
    printf("+------+---------+\n");
    for (int i = 0; i < tripleIndex; i++) {
        printf("| %d | (%c, %s, %s) |\n", i, triples[indirectTriples[i]].op,
               triples[indirectTriples[i]].arg1, triples[indirectTriples[i]].arg2);
    }
    printf("+------+---------+\n");
}

int main() {
    char expr[MAX], postfix[MAX];
    printf("Enter an arithmetic expression: ");
    scanf("%s", expr);
    
    generatePostfix(expr, postfix);
    generate3AC(postfix);
    
    // Print representations
    printQuadruples();
    printTriples();
    printIndirectTriples();
    
    return 0;
}

