#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_PRODS 10
#define MAX_PROD_LEN 50
#define MAX_NT_LEN 10
#define MAX_NON_TERMINALS 20

typedef struct {
    char lhs[MAX_NT_LEN];
    char prods[MAX_PRODS][MAX_PROD_LEN];
    int prod_count;
} NonTerminal;

NonTerminal grammar[MAX_NON_TERMINALS];
int grammar_size = 0;

int common_prefix(const char *a, const char *b, char *prefix) {
    int i = 0;
    while (a[i] != '\0' && b[i] != '\0' && a[i] == b[i]) {
        i++;
    }
    strncpy(prefix, a, i);
    prefix[i] = '\0';
    return i;
}

int compare_strings(const void *a, const void *b) {
    return strcmp(*(const char **)a, *(const char **)b);
}

void find_max_lcp(NonTerminal *nt, char *lcp, int *max_len) {
    *max_len = 0;
    lcp[0] = '\0';
    if (nt->prod_count < 2) return;
    char *prods[MAX_PRODS];
    for (int i = 0; i < nt->prod_count; i++) {
        prods[i] = nt->prods[i];
    }
    qsort(prods, nt->prod_count, sizeof(char *), compare_strings);
    for (int i = 0; i < nt->prod_count - 1; i++) {
        char current_lcp[MAX_PROD_LEN];
        int len = common_prefix(prods[i], prods[i + 1], current_lcp);
        if (len > *max_len) {
            *max_len = len;
            strcpy(lcp, current_lcp);
        }
    }
}

void left_factor(NonTerminal *nt) {
    char lcp[MAX_PROD_LEN];
    int max_len;
    find_max_lcp(nt, lcp, &max_len);
    if (max_len == 0) return;

    char matched_prods[MAX_PRODS][MAX_PROD_LEN];
    int matched_count = 0;
    for (int i = 0; i < nt->prod_count; i++) {
        if (strncmp(nt->prods[i], lcp, max_len) == 0) {
            strcpy(matched_prods[matched_count], nt->prods[i]);
            matched_count++;
        }
    }
    if (matched_count < 2) return;

    // Create new non-terminal (append ')
    char new_nt_name[MAX_NT_LEN];
    snprintf(new_nt_name, MAX_NT_LEN, "%.*s'", MAX_NT_LEN - 2, nt->lhs);
    for (int i = 0; i < grammar_size; i++) {
        if (strcmp(grammar[i].lhs, new_nt_name) == 0) return;
    }
    if (grammar_size >= MAX_NON_TERMINALS) return;

    NonTerminal new_nt;
    strcpy(new_nt.lhs, new_nt_name);
    new_nt.prod_count = 0;

    int new_prod_count = 0;
    for (int i = 0; i < nt->prod_count; i++) {
        if (strncmp(nt->prods[i], lcp, max_len) != 0) {
            strcpy(nt->prods[new_prod_count], nt->prods[i]);
            new_prod_count++;
        }
    }

    // Add factored production (e.g., "aA'")
    char factored_prod[MAX_PROD_LEN];
    strncpy(factored_prod, lcp, MAX_PROD_LEN - 1);
    factored_prod[MAX_PROD_LEN - 1] = '\0';
    strncat(factored_prod, new_nt_name, MAX_PROD_LEN - strlen(factored_prod) - 1);
    strcpy(nt->prods[new_prod_count], factored_prod);
    nt->prod_count = new_prod_count + 1;

    // Add suffixes to new NT
    for (int i = 0; i < matched_count; i++) {
        char suffix[MAX_PROD_LEN];
        strcpy(suffix, matched_prods[i] + max_len);
        if (strlen(suffix) == 0) strcpy(suffix, "ε");
        strcpy(new_nt.prods[new_nt.prod_count], suffix);
        new_nt.prod_count++;
    }

    grammar[grammar_size++] = new_nt;
}

void print_grammar() {
    for (int i = 0; i < grammar_size; i++) {
        printf("%s -> ", grammar[i].lhs);
        for (int j = 0; j < grammar[i].prod_count; j++) {
            printf("%s", grammar[i].prods[j]);
            if (j < grammar[i].prod_count - 1) printf(" | ");
        }
        printf("\n");
    }
}

int main() {
    printf("Enter the number of non-terminals: ");
    int nt_count;
    scanf("%d", &nt_count);
    grammar_size = nt_count;

    for (int i = 0; i < nt_count; i++) {
        printf("Non-terminal %d name: ", i + 1);
        scanf("%s", grammar[i].lhs);
        printf("Number of productions for %s: ", grammar[i].lhs);
        scanf("%d", &grammar[i].prod_count);
        printf("Enter productions (space-separated S aS): ");
        for (int j = 0; j < grammar[i].prod_count; j++) {
            scanf("%s", grammar[i].prods[j]);
        }
    }

    for (int i = 0; i < grammar_size; i++) {
        left_factor(&grammar[i]);
    }

    printf("\nGrammar after left factoring:\n");
    print_grammar();
    return 0;
}

