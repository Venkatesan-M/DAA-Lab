#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_PROD 100
#define MAX_RHS 10
#define MAX_SYMBOLS 100
#define MAX_DERIVATION_LEN 2048  // Increased buffer size to avoid truncation

typedef struct Production {
    char lhs;
    char rhs[MAX_RHS + 1];
    int index;
} Production;

typedef struct State {
    char symbols[MAX_SYMBOLS];
    char derivation[MAX_DERIVATION_LEN];
} State;

typedef struct QueueNode {
    State state;
    struct QueueNode *next;
} QueueNode;

typedef struct {
    QueueNode *front;
    QueueNode *rear;
} Queue;

void enqueue(Queue *q, State state) {
    QueueNode *newNode = (QueueNode*)malloc(sizeof(QueueNode));
    newNode->state = state;
    newNode->next = NULL;
    if (q->rear == NULL) {
        q->front = q->rear = newNode;
    } else {
        q->rear->next = newNode;
        q->rear = newNode;
    }
}

int dequeue(Queue *q, State *state) {
    if (q->front == NULL) return 0;
    QueueNode *temp = q->front;
    *state = temp->state;
    q->front = q->front->next;
    if (q->front == NULL) {
        q->rear = NULL;
    }
    free(temp);
    return 1;
}

// Function to print leftmost derivation
void print_leftmost_derivation(Production productions[], char start_symbol, char *derivation_indices) {
    char current[MAX_SYMBOLS];
    char temp[MAX_SYMBOLS];
    char *indices = strdup(derivation_indices);
    char *token = strtok(indices, ",");
   
    // Start with the start symbol
    snprintf(current, MAX_SYMBOLS, "%c", start_symbol);
    printf("\nLeftmost Derivation:\n");
    printf("%s\n", current);
   
    while (token != NULL) {
        int prod_index = atoi(token);
       
        // Find the leftmost non-terminal
        int pos = -1;
        for (int i = 0; current[i] != '\0'; i++) {
            if (current[i] >= 'A' && current[i] <= 'Z') {
                pos = i;
                break;
            }
        }
       
        if (pos != -1) {
            // Apply the production
            char pre[MAX_SYMBOLS], post[MAX_SYMBOLS];
            strncpy(pre, current, pos);
            pre[pos] = '\0';
            strcpy(post, current + pos + 1);
           
            // Create the new string
            strcpy(temp, pre);
            strcat(temp, productions[prod_index].rhs);
            strcat(temp, post);
            strcpy(current, temp);
           
            printf("%s\n", current);
        }
       
        token = strtok(NULL, ",");
    }
   
    free(indices);
}

int main() {
    Production productions[MAX_PROD];
    int num_productions;
    char start_symbol;
   
    printf("Enter the number of productions: ");
    scanf("%d", &num_productions);
   
    for (int i = 0; i < num_productions; i++) {
        printf("Enter production %d (lhs rhs): ", i + 1);
        scanf(" %c %s", &productions[i].lhs, productions[i].rhs);
        productions[i].index = i;
    }
   
    printf("Enter start symbol: ");
    scanf(" %c", &start_symbol);
   
    Queue queue = { NULL, NULL };
    State initial_state;
    snprintf(initial_state.symbols, MAX_SYMBOLS, "%c", start_symbol);
    initial_state.derivation[0] = '\0';
    enqueue(&queue, initial_state);
   
    typedef struct {
        char string[MAX_SYMBOLS];
        char derivation[MAX_DERIVATION_LEN];
    } GeneratedString;
   
    GeneratedString generated_strings[1000];
    int generated_count = 0;
    int is_ambiguous = 0;
    State current_state;
   
    while (dequeue(&queue, &current_state)) {
        int is_terminal = 1;
        for (int i = 0; current_state.symbols[i] != '\0'; i++) {
            if (current_state.symbols[i] >= 'A' && current_state.symbols[i] <= 'Z') {
                is_terminal = 0;
                break;
            }
        }
       
        if (is_terminal) {
            for (int i = 0; i < generated_count; i++) {
                if (strcmp(generated_strings[i].string, current_state.symbols) == 0) {
                    if (strcmp(generated_strings[i].derivation, current_state.derivation) != 0) {
                        printf("String: %s\n", current_state.symbols);
                        printf("Grammar is ambiguous!\n");
                        printf("Derivation 1: %s\n", generated_strings[i].derivation);
                        printf("Derivation 2: %s\n", current_state.derivation);
                       
                        // Print only the leftmost derivation
                        print_leftmost_derivation(productions, start_symbol, current_state.derivation);
                       
                        is_ambiguous = 1;
                        goto end;
                    }
                }
            }
           
            if (generated_count < 1000) {
                strcpy(generated_strings[generated_count].string, current_state.symbols);
                strcpy(generated_strings[generated_count].derivation, current_state.derivation);
                generated_count++;
            }
        } else {
            int pos = -1;
            char nt = '\0';
           
            // Find the leftmost non-terminal for expansion
            for (int i = 0; current_state.symbols[i] != '\0'; i++) {
                if (current_state.symbols[i] >= 'A' && current_state.symbols[i] <= 'Z') {
                    pos = i;
                    nt = current_state.symbols[i];
                    break;
                }
            }
           
            if (pos == -1) continue;
           
            char pre_part[MAX_SYMBOLS] = {0};
            strncpy(pre_part, current_state.symbols, pos);
            pre_part[pos] = '\0';
           
            char post_part[MAX_SYMBOLS] = {0};
            strcpy(post_part, current_state.symbols + pos + 1);
           
            for (int p = 0; p < num_productions; p++) {
                if (productions[p].lhs == nt) {
                    char new_symbols[MAX_SYMBOLS] = {0};
                    strcpy(new_symbols, pre_part);
                    strcat(new_symbols, productions[p].rhs);
                    strcat(new_symbols, post_part);
                   
                    if (strlen(new_symbols) >= MAX_SYMBOLS) continue;
                   
                    char new_derivation[MAX_DERIVATION_LEN];
                    int written = 0;
                    if (current_state.derivation[0] == '\0') {
                        written = snprintf(new_derivation, MAX_DERIVATION_LEN, "%d", productions[p].index);
                    } else {
                        written = snprintf(new_derivation, MAX_DERIVATION_LEN, "%s,%d",
                                             current_state.derivation, productions[p].index);
                    }
                    if (written < 0 || written >= MAX_DERIVATION_LEN) {
                        fprintf(stderr, "Warning: derivation string was truncated.\n");
                        // Optionally handle this case (e.g., skip or reallocate)
                    }
                   
                    State new_state;
                    strcpy(new_state.symbols, new_symbols);
                    strcpy(new_state.derivation, new_derivation);
                    enqueue(&queue, new_state);
                }
            }
        }
    }
   
end:
    if (!is_ambiguous) {
        printf("Grammar is not ambiguous up to the explored depth.\n");
    }
   
    // Clean up any remaining queue items
    while (dequeue(&queue, &current_state));
   
    return 0;
}

