#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#define MAX_NON_TERMS 10
#define MAX_PROD_LEN 50 // Increased to handle longer productions
#define MAX_PRODS_PER_NT 10
#define MAX_CELL_LEN 100 // Increased to handle multiple entries
struct NonTerminal {
    char name;
    char productions[MAX_PRODS_PER_NT][MAX_PROD_LEN];
    int prod_count;
};
struct NonTerminal non_terms[MAX_NON_TERMS];
int non_term_count = 0;
typedef struct {
    char symbols[20];
    int has_epsilon;
} FirstSet;
typedef struct {
    char symbols[20];
    int has_dollar;
} FollowSet;
FirstSet first[26]; // A-Z mapped to 0-25
FollowSet follow[26];
int is_terminal(char c) {
    return (c != '#' && !(c >= 'A' && c <= 'Z'));
}
int get_index(char c) {
    return c - 'A';
}
void compute_first_of_sequence(char *beta, char *beta_first, int *beta_has_epsilon) {
    beta_first[0] = '\0';
    *beta_has_epsilon = 1;
    for (int i = 0; beta[i] != '\0' && *beta_has_epsilon; i++)
    {
        char symbol = beta[i];
        if (symbol == '#')
        {
            *beta_has_epsilon = 1;
            break;
        } else if (is_terminal(symbol))
        {
            if (!strchr(beta_first, symbol)) {
                strncat(beta_first, &symbol, 1);
            }
            *beta_has_epsilon = 0;
            break;
        }
        else
        {
            int sym_index = get_index(symbol);
            for (int j = 0; j < strlen(first[sym_index].symbols); j++)
            {
                char c = first[sym_index].symbols[j];
                if (!strchr(beta_first, c))
                {
                    strncat(beta_first, &c, 1);
                }
            }
            if (!first[sym_index].has_epsilon)
            {
                *beta_has_epsilon = 0;
            }
        }
    }
}
void compute_first()
{
    int changed;
    do
    {
        changed = 0;
        for (int i = 0; i < non_term_count; i++)
        {
            char nt = non_terms[i].name;
            int nt_index = get_index(nt);
            for (int j = 0; j < non_terms[i].prod_count; j++)
            {
                char *prod = non_terms[i].productions[j];
                int can_derive_epsilon = 1;
                for (int k = 0; prod[k] != '\0' && can_derive_epsilon; k++)
                {
                    char symbol = prod[k];
                    if (symbol == '#') {
                        if (can_derive_epsilon) {
                            if (!first[nt_index].has_epsilon) {
                                first[nt_index].has_epsilon = 1;
                                changed = 1;
                            }
                        }
                        can_derive_epsilon = 0;
                        break;
                    }
                    else if (is_terminal(symbol)) {
                        if (!strchr(first[nt_index].symbols, symbol)) {
                            int len = strlen(first[nt_index].symbols);
                            first[nt_index].symbols[len] = symbol;
                            first[nt_index].symbols[len + 1] = '\0';
                            changed = 1;
                        }
                        can_derive_epsilon = 0;
                        break;
                    }
                    else {
                        int sym_index = get_index(symbol);
                        for (int l = 0; l < strlen(first[sym_index].symbols); l++) {
                            char c = first[sym_index].symbols[l];
                            if (!strchr(first[nt_index].symbols, c)) {
                                int len = strlen(first[nt_index].symbols);
                                first[nt_index].symbols[len] = c;
                                first[nt_index].symbols[len + 1] = '\0';
                                changed = 1;
                            }
                        }
                        if (!first[sym_index].has_epsilon) {
                            can_derive_epsilon = 0;
                        }
                    }
                }
                if (can_derive_epsilon) {
                    if (!first[nt_index].has_epsilon) {
                        first[nt_index].has_epsilon = 1;
                        changed = 1;
                    }
                }
            }
        }
    } while (changed);
}
void compute_follow() {
    for (int i = 0; i < 26; i++) {
        follow[i].symbols[0] = '\0';
        follow[i].has_dollar = 0;
    }
    char start_symbol = non_terms[0].name;
    int start_index = get_index(start_symbol);
    follow[start_index].has_dollar = 1;
    int changed;
    do {
        changed = 0;
        for (int i = 0; i < non_term_count; i++) {
            char A = non_terms[i].name;
            int A_index = get_index(A);
            for (int j = 0; j < non_terms[i].prod_count; j++) {
                char *prod = non_terms[i].productions[j];
                for (int k = 0; prod[k] != '\0'; k++) {
                    char B = prod[k];
                    if (B >= 'A' && B <= 'Z') {
                        int B_index = get_index(B);
                        char beta[MAX_PROD_LEN];
                        strcpy(beta, prod + k + 1);
                        char beta_first[20] = "";
                        int beta_has_epsilon = 0;
                        compute_first_of_sequence(beta, beta_first, &beta_has_epsilon);
                        for (int l = 0; l < strlen(beta_first); l++) {
                            char c = beta_first[l];
                            if (!strchr(follow[B_index].symbols, c)) {
                                int len = strlen(follow[B_index].symbols);
                                follow[B_index].symbols[len] = c;
                                follow[B_index].symbols[len + 1] = '\0';
                                changed = 1;
                            }
                        }
                        if (beta_has_epsilon) {
                            for (int l = 0; l < strlen(follow[A_index].symbols); l++) {
                                char c = follow[A_index].symbols[l];
                                if (!strchr(follow[B_index].symbols, c)) {
                                    int len = strlen(follow[B_index].symbols);
                                    follow[B_index].symbols[len] = c;
                                    follow[B_index].symbols[len + 1] = '\0';
                                    changed = 1;
                                }
                            }
                            if (follow[A_index].has_dollar && !follow[B_index].has_dollar) {
                                follow[B_index].has_dollar = 1;
                                changed = 1;
                            }
                        }
                    }
                }
            }
        }
    } while (changed);
}
void print_set(char nt, FirstSet first_set, FollowSet follow_set, int is_first) {
    printf("%c: { ", nt);
    if (is_first)
    {
        for (int i = 0; i < strlen(first_set.symbols); i++)
        {
            printf("%c", first_set.symbols[i]);
            if (i < strlen(first_set.symbols) - 1 || first_set.has_epsilon) {
                printf(", ");
            }
        }
        if (first_set.has_epsilon) {
            printf("ε");
        }
    }
    else
    {
        for (int i = 0; i < strlen(follow_set.symbols); i++)
        {
            printf("%c", follow_set.symbols[i]);
            if (i < strlen(follow_set.symbols) - 1 || follow_set.has_dollar) {
                printf(", ");
            }
        }
        if (follow_set.has_dollar) {
            printf("$");
        }
    }
    printf(" }\n");
}
int compare_chars(const void *a, const void *b) {
    char c1 = *(const char*)a;
    char c2 = *(const char*)b;
    if (c1 == '$' && c2 != '$') return 1;
    if (c2 == '$' && c1 != '$') return -1;
    return c1 - c2;
}
int main() {
    int n;
    printf("Enter the number of productions (eg. S->aB|d) : ");
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        char line[100];
        printf("Enter production %d: ", i + 1);
        scanf("%s", line);
        char *arrow = strstr(line, "->");
        if (!arrow) {
            printf("Invalid production format.\n");
            return 1;
        }
        *arrow = '\0';
        char lhs = line[0];
        char *rhs = arrow + 2;
        char *alt = strtok(rhs, "|");
        while (alt) {
            char cleaned_alt[MAX_PROD_LEN];
            if (strcmp(alt, "ε") == 0) {
                strcpy(cleaned_alt, "");
            } else {
                strcpy(cleaned_alt, alt);
            }
            int found = 0;
            for (int j = 0; j < non_term_count; j++) {
                if (non_terms[j].name == lhs) {
                    strcpy(non_terms[j].productions[non_terms[j].prod_count], cleaned_alt);
                    non_terms[j].prod_count++;
                    found = 1;
                    break;
                }
            }
            if (!found) {
                non_terms[non_term_count].name = lhs;
                strcpy(non_terms[non_term_count].productions[0], cleaned_alt);
                non_terms[non_term_count].prod_count = 1;
                non_term_count++;
            }
            alt = strtok(NULL, "|");
        }
    }
    for (int i = 0; i < 26; i++) {
        first[i].symbols[0] = '\0';
        first[i].has_epsilon = 0;
    }
    compute_first();
    compute_follow();
    printf("\nFirst sets:\n");
    for (int i = 0; i < non_term_count; i++) {
        char nt = non_terms[i].name;
        int index = get_index(nt);
        print_set(nt, first[index], (FollowSet){"", 0}, 1);
    }
    printf("\nFollow sets:\n");
    for (int i = 0; i < non_term_count; i++) {
        char nt = non_terms[i].name;
        int index = get_index(nt);
        print_set(nt, (FirstSet){"", 0}, follow[index], 0);
    }
    int exists[256] = {0};
    for (int i = 0; i < 26; i++) {
        FirstSet fs = first[i];
        for (int j = 0; j < strlen(fs.symbols); j++) {
            char c = fs.symbols[j];
            if (is_terminal(c)) {
                exists[(unsigned char)c] = 1;
            }
        }
        FollowSet flw = follow[i];
        for (int j = 0; j < strlen(flw.symbols); j++) {
            char c = flw.symbols[j];
            if (is_terminal(c)) {
                exists[(unsigned char)c] = 1;
            }
        }
        if (flw.has_dollar) {
            exists['$'] = 1;
        }
    }
    char terminals[256];
    int term_count = 0;
    for (int c = 0; c < 256; c++) {
        if (exists[c]) {
            terminals[term_count++] = (char)c;
        }
    }
    qsort(terminals, term_count, sizeof(char), compare_chars);
    char table[MAX_NON_TERMS][256][MAX_CELL_LEN];
    for (int i = 0; i < non_term_count; i++) {
        for (int j = 0; j < term_count; j++) {
            table[i][j][0] = '\0';
        }
    }
    for (int i = 0; i < non_term_count; i++) {
        char A = non_terms[i].name;
        int A_index = get_index(A);
        for (int p = 0; p < non_terms[i].prod_count; p++) {
            char *alpha = non_terms[i].productions[p];
            char beta_first[20] = "";
            int beta_has_epsilon = 0;
            compute_first_of_sequence(alpha, beta_first, &beta_has_epsilon);
            for (int k = 0; k < strlen(beta_first); k++) {
                char a = beta_first[k];
                if (a == '#') continue;
                int col = -1;
                for (int j = 0; j < term_count; j++) {
                    if (terminals[j] == a) {
                        col = j;
                        break;
                    }
                }
                if (col == -1) continue;
                char prod_str[MAX_PROD_LEN + 3];
                sprintf(prod_str, "%c->%s", A, (strlen(alpha) == 0) ? "ε" : alpha);
                if (strlen(table[i][col]) == 0) {
                    strcpy(table[i][col], prod_str);
                } else {
                    strcat(table[i][col], " | ");
                    strcat(table[i][col], prod_str);
                }
            }
            if (beta_has_epsilon) {
                FollowSet flw = follow[A_index];
                for (int k = 0; k < strlen(flw.symbols); k++) {
                    char b = flw.symbols[k];
                    int col = -1;
                    for (int j = 0; j < term_count; j++) {
                        if (terminals[j] == b) {
                            col = j;
                            break;
                        }
                    }
                    if (col == -1) continue;
                    char prod_str[MAX_PROD_LEN + 3];
                    sprintf(prod_str, "%c->%s", A, (strlen(alpha) == 0) ? "ε" : alpha);
                    if (strlen(table[i][col]) == 0) {
                        strcpy(table[i][col], prod_str);
                    }
                    else {
                        strcat(table[i][col], " | ");
                        strcat(table[i][col], prod_str);
                    }
                }
                if (flw.has_dollar)
                {
                    int col = -1;
                    for (int j = 0; j < term_count; j++) {
                        if (terminals[j] == '$') {
                            col = j;
                            break;
                        }
                    }
                    if (col != -1) {
                        char prod_str[MAX_PROD_LEN + 3];
                        sprintf(prod_str, "%c->%s", A, (strlen(alpha) == 0) ? "ε" : alpha);
                        if (strlen(table[i][col]) == 0) {
                            strcpy(table[i][col], prod_str);
                        } else {
                            strcat(table[i][col], " | ");
                            strcat(table[i][col], prod_str);
                        }
                    }
                }
            }
        }
    }
    int col_widths[256] = {0};
    for (int j = 0; j < term_count; j++) {
        int max_width = 0;
        for (int i = 0; i < non_term_count; i++) {
            int len = strlen(table[i][j]);
            if (len > max_width) {
                max_width = len;
            }
        }
        if (max_width < 5) max_width = 5;
        col_widths[j] = max_width + 2;
    }
    printf("\nPredictive Parsing Table:\n");
    printf("%-10s", "");
    for (int j = 0; j < term_count; j++) {
        printf("%-*s", col_widths[j], terminals[j] == '$' ? "$" : (char[]){terminals[j], '\0'});
    }
    printf("\n");
    printf("%-10s", "");
    for (int j = 0; j < term_count; j++) {
        for (int k = 0; k < col_widths[j]; k++) printf("-");
    }
    printf("\n");
    for (int i = 0; i < non_term_count; i++) {
        printf("%-10c", non_terms[i].name);
        for (int j = 0; j < term_count; j++) {
            if (table[i][j][0] == '\0') {
                printf("%-*s", col_widths[j], "");
            }
            else {
                printf("%-*s", col_widths[j], table[i][j]);
            }
        }
        printf("\n");
    }
}
