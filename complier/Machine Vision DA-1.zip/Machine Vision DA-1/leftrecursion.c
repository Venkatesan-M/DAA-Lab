#include <stdio.h>
#include <string.h>
#include <ctype.h>

struct ProductionRule {
    char nonTerminal[10];
    char productions[10][100];
    int productionCount;
};

struct ProductionRule grammar[20];
int grammarSize = 0;

void trimWhitespace(char *str) {
    char *start = str;
    while (isspace(*start)) start++;
    char *end = str + strlen(str) - 1;
    while (end > start && isspace(*end)) end--;
    *(end + 1) = '\0';
    memmove(str, start, end - start + 2);
}

void addProduction(char *lhs, char *rhs) {
    int ntIndex = -1;
    for (int i = 0; i < grammarSize; i++) {
        if (strcmp(grammar[i].nonTerminal, lhs) == 0) {
            ntIndex = i;
            break;
        }
    }
    if (ntIndex == -1) {
        strcpy(grammar[grammarSize].nonTerminal, lhs);
        grammar[grammarSize].productionCount = 0;
        ntIndex = grammarSize;
        grammarSize++;
    }
    if (grammar[ntIndex].productionCount >= 10) {
        printf("Too many productions for %s\n", lhs);
        return;
    }
    strcpy(grammar[ntIndex].productions[grammar[ntIndex].productionCount], rhs);
    grammar[ntIndex].productionCount++;
}

void eliminateLeftRecursion() {
    int originalSize = grammarSize;
    for (int i = 0; i < originalSize; i++) {
        struct ProductionRule *rule = &grammar[i];
        int hasLeftRecursion = 0;
        for (int j = 0; j < rule->productionCount; j++) {
            if (strncmp(rule->productions[j], rule->nonTerminal, strlen(rule->nonTerminal)) == 0) {
                hasLeftRecursion = 1;
                break;
            }
        }
        if (!hasLeftRecursion) continue;

        char alphas[10][100];
        int alphaCount = 0;
        char betas[10][100];
        int betaCount = 0;

        for (int j = 0; j < rule->productionCount; j++) {
            char *prod = rule->productions[j];
            if (strncmp(prod, rule->nonTerminal, strlen(rule->nonTerminal)) == 0) {
                strcpy(alphas[alphaCount], prod + strlen(rule->nonTerminal));
                alphaCount++;
            } else {
                strcpy(betas[betaCount], prod);
                betaCount++;
            }
        }

        char newNonTerminal[10];
        strcpy(newNonTerminal, rule->nonTerminal);
        strcat(newNonTerminal, "'");

        int exists = 0;
        for (int j = 0; j < grammarSize; j++) {
            if (strcmp(grammar[j].nonTerminal, newNonTerminal) == 0) {
                exists = 1;
                break;
            }
        }
        if (exists) {
            printf("New non-terminal %s already exists\n", newNonTerminal);
            continue;
        }

        rule->productionCount = 0;
        for (int j = 0; j < betaCount; j++) {
            char newProd[100];
            if (strcmp(betas[j], "ε") == 0) {
                strcpy(newProd, newNonTerminal);
            } else {
                strcpy(newProd, betas[j]);
                strcat(newProd, newNonTerminal);
            }
            strcpy(rule->productions[rule->productionCount], newProd);
            rule->productionCount++;
        }

        if (betaCount == 0) {
            strcpy(rule->productions[rule->productionCount], newNonTerminal);
            rule->productionCount++;
        }

        struct ProductionRule *newRule = &grammar[grammarSize];
        strcpy(newRule->nonTerminal, newNonTerminal);
        newRule->productionCount = 0;

        for (int j = 0; j < alphaCount; j++) {
            char newProd[100];
            strcpy(newProd, alphas[j]);
            strcat(newProd, newNonTerminal);
            strcpy(newRule->productions[newRule->productionCount], newProd);
            newRule->productionCount++;
        }

        strcpy(newRule->productions[newRule->productionCount], "ε");
        newRule->productionCount++;
        grammarSize++;
    }
}

void printGrammar() {
    for (int i = 0; i < grammarSize; i++) {
        printf("%s -> ", grammar[i].nonTerminal);
        for (int j = 0; j < grammar[i].productionCount; j++) {
            printf("%s", grammar[i].productions[j]);
            if (j != grammar[i].productionCount - 1) {
                printf(" | ");
            }
        }
        printf("\n");
    }
}

int main() {
    char line[256];
    printf("Enter production rules (e.g., A -> Aa | b). Empty line to stop:\n");
    while (1) {
        fgets(line, sizeof(line), stdin);
        if (line[0] == '\n') break;

        char *arrow = strstr(line, "->");
        if (!arrow) {
            printf("Invalid syntax. Missing '->'\n");
            continue;
        }

        *arrow = '\0';
        char *lhs = line;
        char *rhs = arrow + 2;
        trimWhitespace(lhs);

        if (strlen(lhs) == 0) {
            printf("Invalid empty non-terminal\n");
            continue;
        }

        char *token = strtok(rhs, "|");
        while (token) {
            char prod[100];
            strcpy(prod, token);
            trimWhitespace(prod);
            if (strlen(prod) > 0) {
                addProduction(lhs, prod);
            }
            token = strtok(NULL, "|");
        }
    }

    eliminateLeftRecursion();

    printf("\nGrammar after eliminating left recursion:\n");
    printGrammar();
}

