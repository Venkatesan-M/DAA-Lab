#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#define MAX_STACK 100
#define MAX_INPUT 100
#define MAX_PROD 20
#define MAX_PROD_LINE 100
#define MAX_TOKEN 20
#define MAX_TOKENS 100

// Production structure holds the left-hand side and right-hand side
typedef struct {
    char lhs[20];
    char rhs[50];
} Production;

// Token structure to hold each lexical unit
typedef struct {
    char value[MAX_TOKEN];
} Token;

Production productions[MAX_PROD];
int num_productions = 0;
char start_symbol[20]; // will be set to LHS of first production

// For tokenized approach
Token stack_tokens[MAX_STACK]; // token stack
int stack_top = -1;            // stack top pointer
Token input_tokens[MAX_INPUT]; // tokenized input
int num_tokens = 0;            // number of tokens in input
int token_ip = 0;              // token input pointer

// Function to print tokens for debugging
void printTokens(Token* tokens, int count) {
    printf("Tokens (%d): ", count);
    for (int i = 0; i < count; i++) {
        printf("'%s' ", tokens[i].value);
    }
    printf("\n");
}

// Print the current state: stack, remaining input, and action taken
void printState(const char *action) {
    char stack_str[MAX_STACK * MAX_TOKEN] = "";
    char input_str[MAX_INPUT * MAX_TOKEN] = "";
    // Build stack display string
    for (int i = 0; i <= stack_top; i++) {
        strcat(stack_str, stack_tokens[i].value);
    }
    // Build input display string
    for (int i = token_ip; i < num_tokens; i++) {
        strcat(input_str, input_tokens[i].value);
    }
    printf("Stack: %-15s Input: %-15s Action: %s\n", stack_str, input_str, action);
}

// Tokenize an input string into separate tokens
void tokenizeInput(const char *input) {
    num_tokens = 0;
    int i = 0;
    while (input[i] != '\0') {
        // Skip whitespace
        while (input[i] != '\0' && isspace(input[i])) {
            i++;
        }
        if (input[i] == '\0')
            break;
        char token_val[MAX_TOKEN] = {0};
        int token_len = 0;
        // Handle non-terminal (capital letter)
        if (isupper(input[i])) {
            token_val[token_len++] = input[i++];
        }
        // Handle identifier keywords (int, float, id, etc.)
        else if (isalpha(input[i])) {
            while (input[i] != '\0' && isalpha(input[i])) {
                token_val[token_len++] = input[i++];
            }
        }
        // Handle special characters/operators
        else {
            token_val[token_len++] = input[i++];
        }
        token_val[token_len] = '\0';
        // Add token to the token array
        if (token_len > 0) {
            strcpy(input_tokens[num_tokens].value, token_val);
            num_tokens++;
        }
    }
}

// Tokenize the productions' RHS strings
void tokenizeProduction(int prod_index) {
    char tokenized_rhs[100] = {0};
    char *rhs = productions[prod_index].rhs;
    int i = 0;
    while (rhs[i] != '\0') {
        char token_val[MAX_TOKEN] = {0};
        int token_len = 0;
        // Handle non-terminal (capital letter)
        if (isupper(rhs[i])) {
            token_val[token_len++] = rhs[i++];
        }
        // Handle identifier keywords (int, float, id, etc.)
        else if (isalpha(rhs[i])) {
            while (rhs[i] != '\0' && isalpha(rhs[i])) {
                token_val[token_len++] = rhs[i++];
            }
        }
        // Handle special characters/operators
        else {
            token_val[token_len++] = rhs[i++];
        }
        token_val[token_len] = '\0';
        // Add space between tokens in the new RHS string
        if (strlen(tokenized_rhs) > 0) {
            strcat(tokenized_rhs, " ");
        }
        strcat(tokenized_rhs, token_val);
    }
    // Update the production's RHS
    strcpy(productions[prod_index].rhs, tokenized_rhs);
}

// Check if the stack ends with the tokens from production's RHS
bool matchesProductionRHS(int prod_index) {
    char rhs_tokens[MAX_PROD][MAX_TOKEN];
    int num_rhs_tokens = 0;
    // Split the RHS into tokens
    char rhs_copy[50];
    strcpy(rhs_copy, productions[prod_index].rhs);
    char *token = strtok(rhs_copy, " ");
    while (token != NULL) {
        strcpy(rhs_tokens[num_rhs_tokens++], token);
        token = strtok(NULL, " ");
    }
    // Check if stack has enough tokens
    if (stack_top + 1 < num_rhs_tokens) {
        return false;
    }
    // Check if the top tokens on the stack match the RHS tokens
    for (int i = 0; i < num_rhs_tokens; i++) {
        int stack_idx = stack_top - num_rhs_tokens + 1 + i;
        if (strcmp(stack_tokens[stack_idx].value, rhs_tokens[i]) != 0) {
            return false;
        }
    }
    return true;
}

// Reduce: replace RHS on stack with LHS
void reduce() {
    bool reduced;
    do {
        reduced = false;
        for (int i = 0; i < num_productions; i++) {
            if (matchesProductionRHS(i)) {
                // Count tokens in RHS
                char rhs_copy[50];
                strcpy(rhs_copy, productions[i].rhs);
                int num_rhs_tokens = 0;
                char *token = strtok(rhs_copy, " ");
                while (token != NULL) {
                    num_rhs_tokens++;
                    token = strtok(NULL, " ");
                }
                // Pop the RHS tokens from the stack
                stack_top -= num_rhs_tokens;
                // Push the LHS onto the stack
                strcpy(stack_tokens[++stack_top].value, productions[i].lhs);
                char action_msg[100];
                sprintf(action_msg, "REDUCE: %s -> %s", productions[i].lhs, productions[i].rhs);
                printState(action_msg);
                reduced = true;
                break; // Restart checking from the first production
            }
        }
    } while (reduced);
}

int main() {
    // Read grammar productions
    printf("Enter the number of productions (L->L,id): ");
    if (scanf("%d", &num_productions) != 1) {
        fprintf(stderr, "Invalid number.\n");
        exit(1);
    }
    getchar(); // consume newline left after scanf
    for (int i = 0; i < num_productions; i++) {
        char prod_line[MAX_PROD_LINE];
        printf("Enter production %d (format A->alpha with no spaces): ", i + 1);
        if (fgets(prod_line, MAX_PROD_LINE, stdin) == NULL) {
            fprintf(stderr, "Error reading production.\n");
            exit(1);
        }
        prod_line[strcspn(prod_line, "\n")] = '\0'; // remove newline
        // Look for "->" separator
        char *arrow = strstr(prod_line, "->");
        if (arrow == NULL) {
            printf("Invalid production format. Try again.\n");
            i--;
            continue;
        }
        // Split into LHS and RHS
        int lhs_len = arrow - prod_line;
        strncpy(productions[i].lhs, prod_line, lhs_len);
        productions[i].lhs[lhs_len] = '\0';
        strcpy(productions[i].rhs, arrow + 2);
        // Tokenize the RHS into spaced tokens
        tokenizeProduction(i);
    }
    // Assume the start symbol is the LHS of the first production
    strcpy(start_symbol, productions[0].lhs);
    // Read the input string for parsing
    char input[MAX_INPUT];
    printf("Enter the input string: ");
    // Use fgets to allow spaces in input (no extra getchar() here)
    if (fgets(input, MAX_INPUT, stdin) == NULL) {
        fprintf(stderr, "Error reading input.\n");
        exit(1);
    }
    input[strcspn(input, "\n")] = '\0'; // remove newline
    // Tokenize the input
    tokenizeInput(input);
    // Append the "$" token to mark end-of-input
    strcpy(input_tokens[num_tokens].value, "$");
    num_tokens++;
    // DEBUG: Print all tokens (including "$")
    printTokens(input_tokens, num_tokens);
    // Initialize the parser stack with "$"
    stack_top = 0;
    strcpy(stack_tokens[0].value, "$");
    token_ip = 0;
    printf("\n%-15s %-15s %s\n", "Stack", "Input", "Action");
    printf("-------------------------------------------------------\n");
    printState("START");
    // Shift-reduce parsing loop:
    // Stop shifting when the next token is "$"
    while (token_ip < num_tokens && strcmp(input_tokens[token_ip].value, "$") != 0) {
        // SHIFT: Push next input token onto the stack
        strcpy(stack_tokens[++stack_top].value, input_tokens[token_ip++].value);
        printState("SHIFT");
        // After each shift, try to reduce as much as possible
        reduce();
    }
    // Final reduction after all shift operations
    reduce();
    if (stack_top == 1 && strcmp(stack_tokens[0].value, "$") == 0 &&
        strcmp(stack_tokens[1].value, start_symbol) == 0 &&
        token_ip < num_tokens && strcmp(input_tokens[token_ip].value, "$") == 0) {
        printState("ACCEPT");
        printf("\nInput accepted.\n");
    } else {
        printState("REJECT");
        printf("\nInput rejected.\n");
    }
    return 0;
}

