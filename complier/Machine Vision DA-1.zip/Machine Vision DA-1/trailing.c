#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

struct Symbol {
    char *name;
    struct Symbol *next;
};

struct Production {
    struct Symbol *symbols;
    struct Production *next;
};

struct NonTerminal {
    char *name;
    struct Production *productions;
    struct Node *leading;
    struct Node *trailing;
    struct NonTerminal *next;
};

struct Node {
    char *symbol;
    struct Node *next;
};

struct NonTerminal *non_terminals = NULL;

char *trim(char *str) {
    char *end;
    // Trim leading space
    while (isspace((unsigned char)*str)) str++;
    if (*str == 0) // All spaces?
        return str;
    // Trim trailing space
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) end--;
    // Write new null terminator
    *(end + 1) = '\0';
    return str;
}

struct NonTerminal *find_non_terminal(const char *name) {
    struct NonTerminal *nt = non_terminals;
    while (nt != NULL) {
        if (strcmp(nt->name, name) == 0) {
            return nt;
        }
        nt = nt->next;
    }
    return NULL;
}

void add_production(struct NonTerminal *nt, struct Symbol *symbols) {
    struct Production *prod = malloc(sizeof(struct Production));
    prod->symbols = symbols;
    prod->next = nt->productions;
    nt->productions = prod;
}

bool is_non_terminal(const char *symbol) {
    return find_non_terminal(symbol) != NULL;
}

bool is_in_set(struct Node *set, const char *symbol) {
    struct Node *node = set;
    while (node != NULL) {
        if (strcmp(node->symbol, symbol) == 0) {
            return true;
        }
        node = node->next;
    }
    return false;
}

void add_to_set(struct Node **set, const char *symbol) {
    if (is_in_set(*set, symbol)) {
        return;
    }
    struct Node *node = malloc(sizeof(struct Node));
    node->symbol = strdup(symbol);
    node->next = *set;
    *set = node;
}

void compute_leading() {
    bool changed;
    do {
        changed = false;
        struct NonTerminal *nt = non_terminals;
        while (nt != NULL) {
            struct Production *prod = nt->productions;
            while (prod != NULL) {
                struct Symbol *symbol = prod->symbols;
                char *first_terminal = NULL;
                while (symbol != NULL) {
                    if (!is_non_terminal(symbol->name)) {
                        first_terminal = symbol->name;
                        break;
                    }
                    symbol = symbol->next;
                }
                if (first_terminal != NULL) {
                    if (!is_in_set(nt->leading, first_terminal)) {
                        add_to_set(&nt->leading, first_terminal);
                        changed = true;
                    }
                }
                if (prod->symbols != NULL) {
                    char *first_sym = prod->symbols->name;
                    if (is_non_terminal(first_sym)) {
                        struct NonTerminal *B = find_non_terminal(first_sym);
                        if (B != NULL) {
                            struct Node *b_leading = B->leading;
                            while (b_leading != NULL) {
                                if (!is_non_terminal(b_leading->symbol)) {
                                    if (!is_in_set(nt->leading, b_leading->symbol)) {
                                        add_to_set(&nt->leading, b_leading->symbol);
                                        changed = true;
                                    }
                                }
                                b_leading = b_leading->next;
                            }
                        }
                    }
                }
                prod = prod->next;
            }
            nt = nt->next;
        }
    } while (changed);
}

void compute_trailing() {
    bool changed;
    do {
        changed = false;
        struct NonTerminal *nt = non_terminals;
        while (nt != NULL) {
            struct Production *prod = nt->productions;
            while (prod != NULL) {
                struct Symbol *symbol = prod->symbols;
                char *last_terminal = NULL;
                while (symbol != NULL) {
                    if (!is_non_terminal(symbol->name)) {
                        last_terminal = symbol->name;
                    }
                    symbol = symbol->next;
                }
                if (last_terminal != NULL) {
                    if (!is_in_set(nt->trailing, last_terminal)) {
                        add_to_set(&nt->trailing, last_terminal);
                        changed = true;
                    }
                }
                struct Symbol *last_sym_node = prod->symbols;
                while (last_sym_node != NULL && last_sym_node->next != NULL) {
                    last_sym_node = last_sym_node->next;
                }
                if (last_sym_node != NULL) {
                    char *last_sym = last_sym_node->name;
                    if (is_non_terminal(last_sym)) {
                        struct NonTerminal *B = find_non_terminal(last_sym);
                        if (B != NULL) {
                            struct Node *b_trailing = B->trailing;
                            while (b_trailing != NULL) {
                                if (!is_non_terminal(b_trailing->symbol)) {
                                    if (!is_in_set(nt->trailing, b_trailing->symbol)) {
                                        add_to_set(&nt->trailing, b_trailing->symbol);
                                        changed = true;
                                    }
                                }
                                b_trailing = b_trailing->next;
                            }
                        }
                    }
                }
                prod = prod->next;
            }
            nt = nt->next;
        }
    } while (changed);
}

void print_set(struct Node *set) {
    struct Node *node = set;
    while (node != NULL) {
        printf("%s", node->symbol);
        node = node->next;
        if (node != NULL) {
            printf(", ");
        }
    }
}

void free_symbols(struct Symbol *symbol) {
    while (symbol != NULL) {
        struct Symbol *next = symbol->next;
        free(symbol->name);
        free(symbol);
        symbol = next;
    }
}

void free_productions(struct Production *prod) {
    while (prod != NULL) {
        struct Production *next = prod->next;
        free_symbols(prod->symbols);
        free(prod);
        prod = next;
    }
}

void free_non_terminals() {
    struct NonTerminal *nt = non_terminals;
    while (nt != NULL) {
        struct NonTerminal *next = nt->next;
        free_productions(nt->productions);
        struct Node *node = nt->leading;
        while (node != NULL) {
            struct Node *next_node = node->next;
            free(node->symbol);
            free(node);
            node = next_node;
        }
        node = nt->trailing;
        while (node != NULL) {
            struct Node *next_node = node->next;
            free(node->symbol);
            free(node);
            node = next_node;
        }
        free(nt->name);
        free(nt);
        nt = next;
    }
}

int main() {
    char line[256];
    int num_productions;
    
    printf("Enter the number of productions (E -> E + T): ");
    fgets(line, sizeof(line), stdin);
    num_productions = atoi(line);
    
    for (int i = 0; i < num_productions; ++i) {
        printf("Production No. %d: ", i + 1);
        if (fgets(line, sizeof(line), stdin) == NULL) {
            fprintf(stderr, "Error reading input.\n");
            exit(1);
        }
        
        size_t len = strlen(line);
        if (len > 0 && line[len - 1] == '\n') {
            line[len - 1] = '\0';
        }
        
        char *arrow = strstr(line, "->");
        if (arrow == NULL) {
            fprintf(stderr, "Invalid production format. Use 'NonTerminal -> symbols...'\n");
            --i; // Retry this production input
            continue;
        }
        
        *arrow = '\0';
        char *lhs = trim(line);
        char *rhs = trim(arrow + 2);
        
        lhs = strdup(lhs);
        
        struct Symbol *symbols = NULL;
        struct Symbol **next_ptr = &symbols;
        
        char *token = strtok(rhs, " ");
        while (token != NULL) {
            struct Symbol *sym = (struct Symbol *)malloc(sizeof(struct Symbol));
            sym->name = strdup(token);
            sym->next = NULL;
            *next_ptr = sym;
            next_ptr = &sym->next;
            token = strtok(NULL, " ");
        }
        
        struct NonTerminal *nt = find_non_terminal(lhs);
        if (nt == NULL) {
            nt = (struct NonTerminal *)malloc(sizeof(struct NonTerminal));
            nt->name = lhs;
            nt->productions = NULL;
            nt->leading = NULL;
            nt->trailing = NULL;
            nt->next = non_terminals;
            non_terminals = nt;
        } else {
            free(lhs);
        }
        
        add_production(nt, symbols);
    }
    
    compute_leading();
    compute_trailing();
    
    printf("\nLeading and Trailing sets:\n");
    struct NonTerminal *nt = non_terminals;
    while (nt != NULL) {
        printf("LEADING(%s) = { ", nt->name);
        print_set(nt->leading);
        printf(" }\n");
        printf("TRAILING(%s) = { ", nt->name);
        print_set(nt->trailing);
        printf(" }\n");
        nt = nt->next;
    }
    
    free_non_terminals();
    return 0;
}
