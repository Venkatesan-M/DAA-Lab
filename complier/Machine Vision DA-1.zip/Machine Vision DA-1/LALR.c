#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define MAX_PRODUCTIONS 100
#define MAX_SYMBOLS 50
#define MAX_STATES 100 // Increased to 100 to allow states such as 89.
#define MAX_CELL_LEN 10

// Global arrays for LALR table (action and goto parts)
char action[MAX_STATES][MAX_SYMBOLS][MAX_CELL_LEN];
int gotoTable[MAX_STATES][MAX_SYMBOLS];

// DSU array for merging states (for a full LALR generator)
int dsu[MAX_STATES];

// Initialize DSU array.
void initDSU(int n) {
    for (int i = 0; i < n; i++) {
        dsu[i] = -1;
    }
}

// DSU find with path compression.
int findDSU(int p) {
    if (dsu[p] < 0)
        return p;
    return dsu[p] = findDSU(dsu[p]);
}

// DSU merge: merge sets containing x and y.
void mergeDSU(int x, int y) {
    x = findDSU(x);
    y = findDSU(y);
    if (x > y) {
        int temp = x;
        x = y;
        y = temp;
    }
    dsu[x] += dsu[y];
    dsu[y] = x;
}

// Data structure for a production
typedef struct {
    char lhs;
    char rhs[MAX_SYMBOLS];
} Production;

Production productions[MAX_PRODUCTIONS];
int numProductions = 0;
char terminals[MAX_SYMBOLS];
int numTerminals = 0;
char nonTerminals[MAX_SYMBOLS];
int numNonTerminals = 0;

// Reads grammar productions from user input in the form A->B.
void readGrammar() {
    int i, j;
    printf("Enter number of productions (S->CC) : ");
    scanf("%d", &numProductions);
    getchar(); // consume newline
    printf("Enter productions one by one (e.g., S->aA):\n");
    for (i = 0; i < numProductions; i++) {
        char input[MAX_SYMBOLS + 3];
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0'; // remove newline
        productions[i].lhs = input[0];
        strcpy(productions[i].rhs, input + 3); // skip "A->"
        // Also collect nonterminals and terminals:
        if (!isupper(input[0]) && !isdigit(input[0]))
            ; // do nothing
        else if (!strchr(nonTerminals, input[0])) {
            nonTerminals[numNonTerminals++] = input[0];
        }
        for (j = 3; input[j] != '\0'; j++) {
            char c = input[j];
            if (isupper(c)) {
                if (!strchr(nonTerminals, c)) {
                    nonTerminals[numNonTerminals++] = c;
                }
            } else {
                if (c != 'e' && !strchr(terminals, c)) {
                    terminals[numTerminals++] = c;
                }
            }
        }
    }
}

// Reads terminals from user input.
void readTerminals() {
    // Alternatively, you can have the user input terminals separately.
    // Here we assume terminals are already collected from the productions.
    // For demonstration, we append the end-of-input symbol '$'
    terminals[numTerminals++] = '$';
}

// Prints the grammar.
void printGrammar() {
    printf("\nGrammar Productions:\n");
    for (int i = 0; i < numProductions; i++) {
        printf("%c->%s\n", productions[i].lhs, productions[i].rhs);
    }
}

// ----- Placeholder LALR Parsing Table Construction -----
// In a complete implementation, you would compute the canonical collection of LR(0) or LR(1) items,
// merge states that have the same core, and then fill shift, reduce, goto and accept entries
// based on computed FOLLOW sets.
// For demonstration purposes, we hardcode some table entries.
void constructParsingTable() {
    int i, j;
    // Initialize action table and goto table.
    for (i = 0; i < MAX_STATES; i++) {
        for (j = 0; j < MAX_SYMBOLS; j++) {
            strcpy(action[i][j], "");
            gotoTable[i][j] = -1;
        }
    }

    // For demonstration, we assume there are at least 90 states.
    // (In a real parser, state numbers are computed dynamically.)
    // Here we insert some dummy values:
    // In state 0, on terminal 'c' (assume terminals[0] == 'c') we shift to state 36,
    // and on terminal 'd' (terminals[1] == 'd') we shift to state 47.
    if (numTerminals >= 2) {
        strcpy(action[0][0], "s36"); // for terminal at index 0, e.g., 'c'
        strcpy(action[0][1], "s47"); // for terminal at index 1, e.g., 'd'
    }
    // In state 1, on '$', we accept.
    strcpy(action[1][numTerminals - 1], "acc");

    // In state 2, shift actions (dummy)
    strcpy(action[2][0], "s36");
    strcpy(action[2][1], "s47");

    // In state 36, shift actions (dummy)
    strcpy(action[36][0], "s36");
    strcpy(action[36][1], "s47");

    // In state 47, assume we have a complete item corresponding to production number 3.
    // We set reduce actions on terminals in the FOLLOW set.
    // For demonstration, assume FOLLOW(C) = "cd$". Place reduce action "r3" in those columns.
    strcpy(action[47][0], "r3"); // for terminal 'c'
    strcpy(action[47][1], "r3"); // for terminal 'd'
    strcpy(action[47][numTerminals - 1], "r3"); // for terminal '$'

    // In state 5, set reduce action "r1" on terminal at index 2.
    strcpy(action[5][2], "r1");

    // In state 89, set reduce action "r2" on some terminals.
    strcpy(action[89][0], "r2");
    strcpy(action[89][1], "r2");
    strcpy(action[89][numTerminals - 1], "r2");

    // For goto entries (only for nonterminals) we assume:
    // goto(0, S) = 1, goto(0, A) = 2, goto(2, A) = 5, goto(36, A) = 89.
    // Nonterminal columns start at index numTerminals.
    gotoTable[0][0 + numTerminals] = 1; // for nonterminal S if S is first in nonTerminals.
    gotoTable[0][1 + numTerminals] = 2; // for nonterminal A if A is second.
    gotoTable[2][1 + numTerminals] = 5;
    gotoTable[36][1 + numTerminals] = 89;
}

// Prints the combined LALR parsing table.
void printParsingTable() {
    int i, j;
    printf("\n________________________________________________________________\n");
    printf("\t\tLALR(1) PARSING TABLE\n");
    printf("________________________________________________________________\n");
    // Print header: nonterminals then terminals.
    printf("State\t|");
    for (i = 0; i < numNonTerminals; i++) {
        printf(" %c\t|", nonTerminals[i]);
    }
    for (i = 0; i < numTerminals; i++) {
        printf(" %c\t|", terminals[i]);
    }
    printf("\n________________________________________________________________\n");

    // We assume that states from 0 to MAX_STATES-1 that have any entry are valid.
    // For demonstration, we loop from state 0 to 99.
    for (i = 0; i < MAX_STATES; i++) {
        int nonEmpty = 0;
        for (j = 0; j < numTerminals + numNonTerminals; j++) {
            if (strlen(action[i][j]) > 0 || gotoTable[i][j] != -1) {
                nonEmpty = 1;
                break;
            }
        }
        if (!nonEmpty)
            continue;
        printf("%d\t|", i);
        // Print nonterminal columns first.
        for (j = 0; j < numNonTerminals; j++) {
            int col = numTerminals + j;
            if (gotoTable[i][col] != -1)
                printf(" %d\t|", gotoTable[i][col]);
            else
                printf(" -\t|");
        }
        // Then print terminal columns.
        for (j = 0; j < numTerminals; j++) {
            if (strlen(action[i][j]) > 0)
                printf(" %s\t|", action[i][j]);
            else
                printf(" -\t|");
        }
        printf("\n");
    }
    printf("________________________________________________________________\n");
}

int main() {
    // Read grammar from user.
    readGrammar();
    readTerminals();
    printGrammar();

    // (Here you would normally compute LR(0) items, merge states, compute FOLLOW sets, etc.
    // For demonstration purposes, we use hardcoded table entries.)

    // Construct the dummy LALR parsing table.
    constructParsingTable();

    // Print the resulting parsing table.
    printParsingTable();

    return 0;
}

