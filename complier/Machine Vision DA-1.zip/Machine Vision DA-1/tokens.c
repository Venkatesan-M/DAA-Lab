#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LEN 100

typedef struct Token
{
    char type[50];
    char value[50];
    struct Token *next;
} Token;

Token *createToken(const char *type, const char *value)
{
    Token *newToken = (Token *)malloc(sizeof(Token));
    strcpy(newToken->type, type);
    strcpy(newToken->value, value);
    newToken->next = NULL;
    return newToken;
}

void insertToken(Token **head, const char *type, const char *value)
{
    Token *newToken = createToken(type, value);
    if (*head == NULL)
    {
        *head = newToken;
    }
    else
    {
        Token *temp = *head;
        while (temp->next)
            temp = temp->next;
        temp->next = newToken;
    }
}

void printTokens(Token *head)
{
    Token *temp = head;
    while (temp)
    {
        printf("%s : %s\n", temp->value, temp->type);
        temp = temp->next;
    }
}

void freeTokens(Token *head)
{
    Token *temp;
    while (head)
    {
        temp = head;
        head = head->next;
        free(temp);
    }
}

// Updated Keyword List
const char *keywords[] = {
    "int", "float", "char", "double", "if", "else", "while", "return", "for", "switch", "case"};

const char operators[] = {'+', '-', '*', '/', '=', '<', '>', '!', '&', '|', '%', '^'};
const char separators[] = {',', ';', '(', ')', '{', '}', '[', ']', '"', '\''};

int isKeyword(const char *str)
{
    for (int i = 0; i < 11; ++i)
    {
        if (strcmp(str, keywords[i]) == 0)
            return 1;
    }
    return 0;
}

int isOperator(char ch)
{
    for (int i = 0; i < 12; ++i)
    {
        if (ch == operators[i])
            return 1;
    }
    return 0;
}

int isSeparator(char ch)
{
    for (int i = 0; i < 10; ++i)
    {
        if (ch == separators[i])
            return 1;
    }
    return 0;
}

// Main Lexical Analyzer
void lexicalAnalysis(const char *code)
{
    Token *head = NULL;
    int i = 0;
    char buffer[MAX_LEN];

    while (code[i] != '\0')
    {
        if (isspace(code[i]))
        {
            i++;
            continue;
        }

        // Identifiers or Keywords or Arrays
        if (isalpha(code[i]) || code[i] == '_')
        {
            int j = 0;
            while (isalnum(code[i]) || code[i] == '_')
                buffer[j++] = code[i++];
            buffer[j] = '\0';

            if (isKeyword(buffer))
                insertToken(&head, "Keyword", buffer);
            else
                insertToken(&head, "Identifier", buffer);

            // Check for Array Initialization
            if (code[i] == '[')
            {
                insertToken(&head, "Array Declaration", "Array");
                i++; // Skip '['
                j = 0;
                while (isdigit(code[i]))
                    buffer[j++] = code[i++];
                buffer[j] = '\0';
                insertToken(&head, "Array Size", buffer);

                if (code[i] == ']')
                {
                    i++; // Skip ']'
                }
            }
        }

        // Numbers
        else if (isdigit(code[i]))
        {
            int j = 0;
            while (isdigit(code[i]) || code[i] == '.')
                buffer[j++] = code[i++];
            buffer[j] = '\0';
            insertToken(&head, "Number", buffer);
        }

        // Operators
        else if (isOperator(code[i]))
        {
            char op[3] = {code[i], '\0'};
            if ((code[i] == '=' || code[i] == '!' || code[i] == '<' || code[i] == '>') && code[i + 1] == '=')
            {
                op[1] = code[i + 1];
                op[2] = '\0';
                i++;
            }
            insertToken(&head, "Operator", op);
            i++;
        }

        // Separators
        else if (isSeparator(code[i]))
        {
            char sep[2] = {code[i], '\0'};
            insertToken(&head, "Separator", sep);
            i++;
        }

        else
        {
            i++; // Skip unknown characters
        }
    }

    printTokens(head);
    freeTokens(head);
}

int main()
{
    char code[MAX_LEN];
    printf("Enter the code:\n");
    fgets(code, MAX_LEN, stdin);
    lexicalAnalysis(code);
    return 0;
}
